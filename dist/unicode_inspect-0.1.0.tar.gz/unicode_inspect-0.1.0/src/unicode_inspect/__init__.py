from .core import describe_char, describe_text

__all__ = ["describe_char", "describe_text"]